package br.edu.fatecpg.viacep.controller;

import br.edu.fatecpg.viacep.model.Endereco;
import java.sql.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject;

public class EnderecoController {

    private static final String URL_DB = "jdbc:postgresql://localhost:5432/viacepdb";
    private static final String USER = "postgres";
    private static final String PASS = "postgres";

    public Endereco buscarEndereco(String cep) {
        try {
            URL url = new URL("https://viacep.com.br/ws/" + cep + "/json/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            Scanner sc = new Scanner(conn.getInputStream());
            StringBuilder json = new StringBuilder();
            while (sc.hasNext()) {
                json.append(sc.nextLine());
            }
            sc.close();

            JSONObject obj = new JSONObject(json.toString());
            if (obj.has("erro")) {
                System.out.println("CEP inválido!");
                return null;
            }

            return new Endereco(
                    obj.getString("cep"),
                    obj.optString("logradouro", ""),
                    obj.optString("bairro", ""),
                    obj.optString("localidade", ""),
                    obj.optString("uf", "")
            );

        } catch (Exception e) {
            System.out.println("Erro ao buscar endereço: " + e.getMessage());
            return null;
        }
    }

    public void salvarEndereco(Endereco endereco) {
        try (Connection conn = DriverManager.getConnection(URL_DB, USER, PASS)) {
            String sql = "INSERT INTO enderecos (cep, logradouro, bairro, localidade, uf) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, endereco.getCep());
            stmt.setString(2, endereco.getLogradouro());
            stmt.setString(3, endereco.getBairro());
            stmt.setString(4, endereco.getLocalidade());
            stmt.setString(5, endereco.getUf());
            stmt.executeUpdate();
            System.out.println("Endereço salvo no banco!");
        } catch (Exception e) {
            System.out.println("Erro ao salvar endereço: " + e.getMessage());
        }
    }

    public void listarEnderecos() {
        try (Connection conn = DriverManager.getConnection(URL_DB, USER, PASS)) {
            String sql = "SELECT * FROM enderecos";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                System.out.println(
                        rs.getString("cep") + " - " +
                        rs.getString("logradouro") + ", " +
                        rs.getString("bairro") + ", " +
                        rs.getString("localidade") + "/" +
                        rs.getString("uf")
                );
            }
        } catch (Exception e) {
            System.out.println("Erro ao listar endereços: " + e.getMessage());
        }
    }
}
